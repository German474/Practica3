﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereInfo : MonoBehaviour
{
    Vector3 pos;
    int fail = 0;
    // Start is called before the first frame update
    void Start()
    {
        pos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        pos.y -= 100 * Time.deltaTime;
        transform.position = pos;
        if(pos.y < -505)
        {
            this.gameObject.SetActive(false);
            Destroy(this);
            Fail();
        }
    }

    private void Fail()
    {
        fail++;
        if(fail > 3)
        {
            Application.Quit();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Manegers.Instance.updateText();
            this.gameObject.SetActive(false);
            Destroy(this);
        }
    }
}
