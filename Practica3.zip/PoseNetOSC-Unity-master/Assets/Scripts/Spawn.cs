﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject myPrefab;
    float time = 0.0f;
    // Start is called before the first frame update

    private void FixedUpdate()
    {
        if (time - Time.time < 0)
        {
            Instantiate(myPrefab, new Vector3(Random.Range(-250f, 250f), 510, 0), Quaternion.identity);
            time = Time.time + 4.0f;
        }
    }
}
