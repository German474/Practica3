﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Manegers : MonoBehaviour
{
    public static Manegers Instance;
    public Text count_text;
    int count = 0;
    public AudioClip TakeSphere; // 2

    private Vector3 cameraPosition; // 5
    // Start is called before the first frame update
    void Start()
    {
        Instance = this;
        count_text.text = "Points: " + count.ToString();
        cameraPosition = Camera.main.transform.position; // 2
    }

    private void PlaySound(AudioClip clip) // 1
    {
        AudioSource.PlayClipAtPoint(clip, cameraPosition); // 2
    }

    public void updateText()
    {
        PlaySound(TakeSphere);
        count++;
        count_text.text = "Points: " + count.ToString();
    }
}
